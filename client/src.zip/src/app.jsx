import React from 'react'
import ReactDom from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css';
import Main from './Main.jsx'


ReactDom.render(<Main />, document.getElementById('root'));
