import React from 'react'
import profileIcon from '../imgs/profile-icon.png';

const Image = () => (
    <img src={profileIcon} alt="" />
)

export default Image